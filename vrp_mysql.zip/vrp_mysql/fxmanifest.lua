
fx_version 'cerulean'
games {  'gta5' }

description "vRP MySQL async - Modified Version"
dependency "oxmysql"
-- server scripts
server_scripts{ 
  "@vrp/lib/utils.lua",
  "MySQL.lua"
}

