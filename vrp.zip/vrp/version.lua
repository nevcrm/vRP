return 8.7
