-- PlayerPed = nil;
-- PlayerUtilId = nil;
-- PlayerCoords = nil;

-- PlayerUtilId = PlayerId()
-- PlayerPed = PlayerPedId()
-- PlayerCoords = GetEntityCoords(PlayerPed)


-- Citizen.CreateThread(function()
--     while true do 
--         Wait(250)
--         PlayerUtilId = PlayerId()
--         PlayerPed = PlayerPedId()
--         PlayerCoords = GetEntityCoords(PlayerPed)        
--     end
-- end)
-- WIP TO be used soon for optimizations.