local cfg = {}

cfg = {
  thirst_per_minute = 0.5,
  hunger_per_minute = 0.5,
  overflow_damage_factor = 2,
  pvp = true,
  police = false
}

return cfg
