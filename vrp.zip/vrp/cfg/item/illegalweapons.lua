
local items = {}

items["AK47"] = {"AK47","Russian hardware."}
items["M4A1"] = {"M4A1","American freedom."}

return items